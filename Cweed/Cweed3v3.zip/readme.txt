Cweed V3.3 2011 Oct 08

Run  go.bat  to recompile using the supplied Win32Forth V6.05H (with Win7 support)

Configuration options are at the top of the file Cweed.f
File parsing is in files.f

Run Cweed.exe and select the file to tidy up.

Enjoy!
Howerd Oakford www.inventio.co.uk